package com.pengrad.telegrambot.model.request;

/**
 * stas
 * 10/21/15.
 */
public enum ChatAction {
    typing, upload_photo, record_video, upload_video, record_audio, upload_audio, upload_document, find_location,
    record_video_note, upload_video_note
}
